<?php 
require_once("config.php");

$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();







?>