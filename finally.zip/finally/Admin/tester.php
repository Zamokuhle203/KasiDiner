<div class="profile">
    <?php
            if (isset($fetch_profile)) {
               echo '<p>' . $fetch_profile['name'] . '</p>';
               echo '<a href="update_profile.php" class="btn">update profile</a>';
            }
            ?>
    <div class="flex-btn">
        <?php
               if (!isset($fetch_profile)) {
                  echo '<a href="admin_login.php" class="option-btn">login</a>';
                  echo '<a href="register_admin.php" class="option-btn">register</a>';
               }
               ?>
        <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');"
            class="delete-btn">logout</a>
    </div>
</div>