<?php

require_once('../components/connect.php');
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

session_start();

if (isset($_POST['submit'])) {

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $entered_pass = $_POST['pass'];

   $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE name = ? AND password = ?");
   $select_admin->bind_param("ss", $name, $entered_pass);
   $select_admin->execute();

   if ($select_admin->errno) {
      die('Error executing query: ' . $select_admin->error);
   }

   $result = $select_admin->get_result(); // Assign $result here

   if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      echo "Name: " . $name . "<br>";
      if (!is_null($row) && $entered_pass === $row['password']) {
         $_SESSION['id'] = $row['id']; // Use the id from the fetched row
         header('location:dashboard.php');
         exit();
      } else {
         $message[] = 'Incorrect username or password!' . mysqli_error($conn);
      }
   } else {
      $message[] = 'No user found with the provided credentials.';
   }
}

?>

<?php
if (isset($result)) {
   echo "Result: " . print_r($result, true) . "<br>";
}

if (isset($row)) {
   echo "Row: " . print_r($row, true) . "<br>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/admin_style.css">

</head>

<body>

    <?php
   if (isset($message)) {
      foreach ($message as $message) {
         echo '
      <div class="message">
         <span>' . $message . '</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
      }
   }
   ?>

    <!-- admin login form section starts  -->

    <section class="form-container">

        <form action="" method="POST">
            <h3>login now</h3>
            <p>default username = <span>admin</span> & password = <span>111</span></p>
            <input type="text" name="name" maxlength="20" required placeholder="enter your username" class="box"
                oninput="this.value = this.value.replace(/\s/g, '')">
            <input type="password" name="pass" maxlength="20" required placeholder="enter your password" class="box"
                oninput="this.value = this.value.replace(/\s/g, '')">
            <input type="submit" name="submit" value="login now" class="btn">
        </form>

    </section>

    <!-- admin login form section ends -->
</body>

</html>