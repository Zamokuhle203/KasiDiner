<?php

require_once '../components/connect.php';
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();


// Check if $admin_id is set before using it
$admin_id = isset($admin_id) ? $admin_id : null;




// Check if admin_id is set in the session
$admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

// Fetch admin profile information only if admin_id is set
if ($admin_id) {
    $select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
    $select_profile->bind_param("i", $admin_id);
    $select_profile->execute();
    $result = $select_profile->get_result();
    $fetch_profile = $result->fetch_assoc();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admins accounts</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/admin_style.css">

</head>

<body>

    <?php include '../components/admin_header.php' ?>

    <!-- admins accounts section starts  -->

    <section class="accounts">

        <h1 class="heading">admins account</h1>

        <div class="box-container">

            <div class="box">
                <p>register new admin</p>
                <a href="register_admin.php" class="option-btn">register</a>
            </div>

            <?php
            $select_account = $conn->prepare("SELECT * FROM `admin`");
            $select_account->execute();
            $result = $select_account->get_result();

            if ($result->num_rows > 0) {
                while ($fetch_accounts = $result->fetch_assoc()) {
            ?>
                    <div class="box">
                        <p> admin id : <span><?= $fetch_accounts['id']; ?></span> </p>
                        <p> username : <span><?= $fetch_accounts['name']; ?></span> </p>
                        <div class="flex-btn">
                            <a href="admin_accounts.php?delete=<?= $fetch_accounts['id']; ?>" class="delete-btn" onclick="return confirm('delete this account?');">delete</a>
                            <?php
                            if ($fetch_accounts['id'] == $admin_id) {
                                echo '<a href="update_profile.php" class="option-btn">update</a>';
                            }
                            ?>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p class="empty">no accounts available</p>';
            }
            ?>

        </div>

    </section>

    <!-- admins accounts section ends -->




















    <!-- custom js file link  -->
    <script src="../js/admin_script.js"></script>

</body>

</html>