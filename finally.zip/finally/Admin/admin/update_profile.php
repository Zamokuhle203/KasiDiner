<?php

require_once '../components/connect.php';
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
   // Initialize variables
   $prev_pass = '';

   // Fetch the previous password
   $select_old_pass = $conn->prepare("SELECT password FROM `admin` WHERE id = ?");
   $select_old_pass->bind_param("i", $admin_id);
   $select_old_pass->execute();
   $result_old_pass = $select_old_pass->get_result();

   if ($result_old_pass->num_rows > 0) {
      $fetch_prev_pass = $result_old_pass->fetch_assoc();
      $prev_pass = $fetch_prev_pass['password'];
   }

   $result_old_pass->close();
   $select_old_pass->close();

   // Validate and sanitize form inputs
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $old_pass = mysqli_real_escape_string($conn, $_POST['old_pass']);
   $new_pass = mysqli_real_escape_string($conn, $_POST['new_pass']);

   // Verify old password
   if (password_verify($old_pass, $prev_pass)) {
      // Hash new password
      $hashed_password = password_hash($new_pass, PASSWORD_DEFAULT);

      // Update the password in the database
      $update_pass = $conn->prepare("UPDATE `admin` SET password = ? WHERE id = ?");
      $update_pass->bind_param("si", $hashed_password, $admin_id);
      $update_pass->execute();

      $_SESSION['success'] = 'Password updated successfully!';
   } else {
      $_SESSION['error'] = 'Old password is incorrect.';
   }

   // Update username
   $select_name = $conn->prepare("SELECT * FROM `admin` WHERE name = ? AND id != ?");
   $select_name->bind_param("si", $name, $admin_id);
   $select_name->execute();
   $result_name = $select_name->get_result();
   $num_rows = $result_name->num_rows;

   if ($num_rows > 0) {
      $_SESSION['error'] = 'Username already taken!';
   } else {
      $update_name = $conn->prepare("UPDATE `admin` SET name = ? WHERE id = ?");
      $update_name->bind_param("si", $name, $admin_id);
      $update_name->execute();
      $_SESSION['success'] = 'Username updated successfully!';
   }

   $result_name->close();
   $select_name->close();

   // Redirect to dashboard page
   header("Location: dashboard.php");
   exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Profile Update</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>

<body>

   <?php include '../components/admin_header.php' ?>

   <!-- admin profile update section starts  -->

   <section class="form-container">
      <form action="" method="POST">
         <h3>Update Profile</h3>
         <input type="text" name="name" maxlength="20" class="box" oninput="this.value = this.value.replace(/\s/g, '')" placeholder="<?= isset($fetch_profile['name']) ? $fetch_profile['name'] : ''; ?>">
         <input type="password" name="old_pass" maxlength="20" placeholder="Enter your old password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
         <input type="password" name="new_pass" maxlength="20" placeholder="Enter your new password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
         <input type="password" name="confirm_pass" maxlength="20" placeholder="Confirm your new password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
         <input type="submit" value="Update Now" name="submit" class="btn">
      </form>
   </section>

   <!-- admin profile update section ends -->

   <!-- Display messages -->
   <?php
   if (!empty($message)) {
      foreach ($message as $msg) {
         echo '<div class="message"><span>' . $msg . '</span><i class="fas fa-times" onclick="this.parentElement.remove();"></i></div>';
      }
   }
   ?>

   <!-- custom js file link  -->
   <script src="../js/admin_script.js"></script>

</body>

</html>