<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('../components/connect.php');

$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['id'])) {
    header("Location: login.php"); // Adjust the login page URL accordingly
    exit();
}

$admin_id = $_SESSION['id'];

// Fetch admin profile information
$select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
$select_profile->bind_param("i", $admin_id);
$select_profile->execute();
$result = $select_profile->get_result();
$fetch_profile = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashboard</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/admin_style.css">

</head>

<body>

    <?php include '../components/admin_header.php' ?>

    <!-- admin dashboard section starts  -->

    <section class="dashboard">

        <h1 class="heading">dashboard</h1>

        <div class="box-container">

            <div class="box">
                <h3>welcome!</h3>
                <p><?= $fetch_profile['name']; ?></p>
                <a href="update_profile.php" class="btn">update profile</a>
            </div>

            <div class="box">
                <?php
                $total_pendings = 0;
                $select_pendings = $conn->prepare("SELECT * FROM `orders` WHERE payment_status = ?");
                $select_pendings->bind_param("s", $status_pending);
                $status_pending = 'pending';
                $select_pendings->execute();
                var_dump($conn->error);
                $result_pendings = $select_pendings->get_result();
                while ($fetch_pendings = $result_pendings->fetch_assoc()) {
                    var_dump($fetch_pendings['total_price']);
                    $total_pendings += $fetch_pendings['total_price'];
                }
                ?>
                <h3><span>$</span><?= $total_pendings; ?><span>/-</span></h3>
                <p>total pendings</p>
                <a href="placed_orders.php" class="btn">see orders</a>
            </div>

            <div class="box">
                <?php
                $total_completes = 0;
                $select_completes = $conn->prepare("SELECT * FROM `orders` WHERE payment_status = ?");
                $select_completes->bind_param("s", $status_completed);
                $status_completed = 'completed';
                $select_completes->execute();
                var_dump($conn->error);
                $result_completes = $select_completes->get_result();
                while ($fetch_completes = $result_completes->fetch_assoc()) {
                    var_dump($fetch_completes['total_price']);
                    $total_completes += $fetch_completes['total_price'];
                }
                ?>
                <h3><span>$</span><?= $total_completes; ?><span>/-</span></h3>
                <p>total completes</p>
                <a href="placed_orders.php" class="btn">see orders</a>
            </div>

            <div class="box">
                <?php
                $select_orders = $conn->prepare("SELECT * FROM `orders`");
                $select_orders->execute();
                var_dump($conn->error);
                $numbers_of_orders = $select_orders->num_rows;
                ?>
                <h3><?= $numbers_of_orders; ?></h3>
                <p>total orders</p>
                <a href="placed_orders.php" class="btn">see orders</a>
            </div>

            <div class="box">
                <?php
                $select_products = $conn->prepare("SELECT * FROM `products`");
                $select_products->execute();
                $result_products = $select_products->get_result();
                $select_products->close();  // Close the prepared statement after fetching result set

                var_dump($conn->error);

                $numbers_of_products = $result_products->num_rows;
                ?>
                <h3><?= $numbers_of_products; ?></h3>
                <p>products added</p>
                <a href="products.php" class="btn">see products</a>
            </div>




            <div class="box">
                <?php
                $select_users = $conn->prepare("SELECT * FROM `users`");
                $select_users->execute();
                var_dump($conn->error);
                $numbers_of_users = $select_users->num_rows;
                ?>
                <h3><?= $numbers_of_users; ?></h3>
                <p>users accounts</p>
                <a href="users_accounts.php" class="btn">see users</a>
            </div>

            <div class="box">
                <?php
                $select_admins = $conn->prepare("SELECT * FROM `admin`");
                $select_admins->execute();
                var_dump($conn->error);
                $numbers_of_admins = $select_admins->num_rows;
                ?>
                <h3><?= $numbers_of_admins; ?></h3>
                <p>admins</p>
                <a href="admin_accounts.php" class="btn">see admins</a>
            </div>

            <div class="box">
                <?php
                $select_messages = $conn->prepare("SELECT * FROM `messages`");
                $select_messages->execute();
                var_dump($conn->error);
                $numbers_of_messages = $select_messages->num_rows;
                ?>
                <h3><?= $numbers_of_messages; ?></h3>
                <p>new messages</p>
                <a href="messages.php" class="btn">see messages</a>
            </div>

        </div>

    </section>

    <!-- admin dashboard section ends -->

    <!-- custom js file link  -->
    <script src="../js/admin_script.js"></script>

</body>

</html>