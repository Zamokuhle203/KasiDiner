<?php


require_once '../components/connect.php';
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}
session_start();

include '../components/admin_header.php';
// Check if $admin_id is set before using it
$admin_id = isset($admin_id) ? $admin_id : null;




// Check if admin_id is set in the session
$admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

// Fetch admin profile information only if admin_id is set
if ($admin_id) {
   $select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
   $select_profile->bind_param("i", $admin_id);
   $select_profile->execute();
   $result = $select_profile->get_result();
   $fetch_profile = $result->fetch_assoc();
}

// Rest of your code...


if (isset($_POST['add_product'])) {
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $price = mysqli_real_escape_string($conn, $_POST['price']);
   $category = mysqli_real_escape_string($conn, $_POST['category']);

   $image = mysqli_real_escape_string($conn, $_FILES['image']['name']);
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = '../uploaded_img/' . $image;

   $select_products = $conn->prepare("SELECT * FROM `products` WHERE name = ?");
   $select_products->bind_param("s", $name);
   $select_products->execute();

   if ($select_products->get_result()->num_rows > 0) {
      $message[] = 'Product name already exists!';
   } else {
      if ($image_size > 2000000) {
         $message[] = 'Image size is too large';
      } else {
         move_uploaded_file($image_tmp_name, $image_folder);

         $insert_product = $conn->prepare("INSERT INTO `products`(name, category, price, image) VALUES(?,?,?,?)");
         $insert_product->bind_param("ssds", $name, $category, $price, $image);
         $insert_product->execute();

         $message[] = 'New product added!';
      }
   }
}

if (isset($_GET['delete'])) {
   $delete_id = $_GET['delete'];

   // Fetch product image
   $delete_product_image = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
   $delete_product_image->bind_param("i", $delete_id);
   $delete_product_image->execute();
   $result = $delete_product_image->get_result();
   $fetch_delete_image = $result->fetch_assoc();

   // Delete product image file
   unlink('../uploaded_img/' . $fetch_delete_image['image']);

   // Delete product record
   $delete_product = $conn->prepare("DELETE FROM `products` WHERE id = ?");
   $delete_product->bind_param("i", $delete_id);
   $delete_product->execute();

   // Delete related cart entries
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE pid = ?");
   $delete_cart->bind_param("i", $delete_id);
   $delete_cart->execute();

   header('location: products.php');
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>products</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>

<body>



   <!-- add products section starts  -->
   <section class="add-products">

      <form action="" method="POST" enctype="multipart/form-data">
         <h3>add product</h3>
         <input type="text" required placeholder="enter product name" name="name" maxlength="100" class="box">
         <input type="number" min="0" max="9999999999" required placeholder="enter product price" name="price" onkeypress="if(this.value.length == 10) return false;" class="box">
         <select name="category" class="box" required>
            <option value="" disabled selected>select category --</option>
            <option value="main dish">main dish</option>
            <option value="fast food">fast food</option>
            <option value="drinks">drinks</option>
            <option value="desserts">desserts</option>
         </select>
         <input type="file" name="image" class="box" accept="image/jpg, image/jpeg, image/png, image/webp" required>
         <input type="submit" value="add product" name="add_product" class="btn">
      </form>

   </section>

   <!-- add products section ends -->

   <!-- show products section starts  -->

   <section class="show-products" style="padding-top: 0;">

      <div class="box-container">

         <?php
         $show_products = $conn->prepare("SELECT * FROM `products`");
         $show_products->execute();

         // Use mysqli_stmt_num_rows for mysqli prepared statements
         $result = $show_products->get_result();

         if ($result->num_rows > 0) {
            while ($fetch_products = $result->fetch_assoc()) {
         ?>
               <div class="box">
                  <img src="../uploaded_img/<?= $fetch_products['image']; ?>" alt="">
                  <div class="flex">
                     <div class="price"><span>R</span><?= $fetch_products['price']; ?><span></span></div>
                     <div class="category"><?= $fetch_products['category']; ?></div>
                  </div>
                  <div class="name"><?= $fetch_products['name']; ?></div>
                  <div class="flex-btn">
                     <a href="update_product.php?update=<?= $fetch_products['id']; ?>" class="option-btn">update</a>
                     <a href="products.php?delete=<?= $fetch_products['id']; ?>" class="delete-btn" onclick="return confirm('delete this product?');">delete</a>
                  </div>
               </div>
         <?php
            }
         } else {
            echo '<p class="empty">no products added yet!</p>';
         }
         ?>

      </div>

   </section>


   <!-- show products section ends -->










   <!-- custom js file link  -->
   <script src="../js/admin_script.js"></script>

</body>

</html>