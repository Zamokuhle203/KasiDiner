<?php

require_once('connect.php'); // Adjust the path as needed

if (isset($_POST['add_to_cart'])) {
   // Assuming $user_id is defined somewhere in your code
   //$user_id = ''; // Replace this with your actual logic to get user ID

   /*if ($user_id == '') {
      header('location: login.php');
      exit();
   } else {*/
   $pid = $_POST['pid'];
   $name = $_POST['name'];
   $price = $_POST['price'];
   $image = $_POST['image'];
   $qty = $_POST['qty'];

   // Assuming $conn is defined somewhere in your code
   $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
   if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
   }

   // Check cart numbers
   $check_cart_numbers = $conn->prepare("SELECT * FROM `cart` WHERE name = ? AND user_id = ?");
   $check_cart_numbers->bind_param("si", $name, $user_id);
   $check_cart_numbers->execute();
   $check_cart_numbers_result = $check_cart_numbers->get_result();

   if ($check_cart_numbers_result->num_rows > 0) {
      $message[] = 'Already added to cart!';
   } else {
      // Insert into cart
      $insert_cart = $conn->prepare("INSERT INTO `cart` (id, user_id, pid, name, price, quantity, image) VALUES (NULL, ?, ?, ?, ?, ?, ?)");
      $insert_cart->bind_param("isssis", $user_id, $pid, $name, $price, $qty, $image);
      $insert_cart->execute();
      $message[] = 'Added to cart!';
   }

   // Close prepared statements
   $check_cart_numbers->close();
   $insert_cart->close();

   // Close the database connection
   mysqli_close($conn);
}
