<?php
require_once('components/connect.php');

// Establish database connection
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DB_NAME);
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

session_start();

// Redirect if the user is not logged in
if (!isset($_SESSION['id'])) {
   header('location:home.php');
   exit();
}

// Fetch orders
$select_orders = $conn->prepare("SELECT * FROM `orders`");
$select_orders->execute();

if ($select_orders->errno) {
   die('Error executing query: ' . $select_orders->error);
}

$result = $select_orders->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Orders</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
   <style>
      /* Add a border to the table */
      .table {
         border-collapse: collapse;
         width: 100%;
      }

      /* Style the table headers */
      .table th,
      .table td {
         border: 1px solid #ddd;
         padding: 8px;
         text-align: left;
      }
   </style>
</head>

<body>

   <section class="table-container">
      <h2>Orders</h2>
      <table class="table">
         <thead>
            <tr>
               <th>ID</th>
               <th>Customer Name</th>
               <th>Product Name</th>
               <th>Quantity</th>
               <th>Total Price</th>
            </tr>
         </thead>
         <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
               echo '<tr>
                        <td>' . $row['id'] . '</td>
                        <td>' . (isset($row['customer_name']) ? $row['customer_name'] : '') . '</td>
                        <td>' . (isset($row['product_name']) ? $row['product_name'] : '') . '</td>
                        <td></td> <!-- You can add data for Quantity here -->
                        <td>' . $row['total_price'] . '</td>
                      </tr>';
            }
            ?>
         </tbody>
      </table>
   </section>

</body>

</html>

<?php
// Close the database connection
mysqli_close($conn);
?>