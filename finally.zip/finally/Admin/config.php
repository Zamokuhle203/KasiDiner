<?php
define('SERVERNAME', "cs3-dev.ict.ru.ac.za");
define('USERNAME', 'G20N9632');
define('PASSWORD', 'G20N9632');
define('DB_NAME', 'G20N9632');

//define('DB_NAME', 'team14');
