<?php
define('SERVERNAME', "cs3-dev.ict.ru.ac.za");
define('USERNAME', 'G20G3211');
define('PASSWORD', 'G20G3211');
define('DB_NAME', 'team14');

//define('DB_NAME', 'team14');


?>